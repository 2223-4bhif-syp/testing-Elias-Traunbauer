import org.mockito.MockedStatic;
import org.mockito.Mockito;

import java.io.IOException;

import static org.mockito.Mockito.*;

public class Main {

    public static void main(String[] args) {

        Internet internet = mock(Internet.class);

        try {

            when(internet.testWebpage("https://google.com")).thenReturn(true);
            doReturn(false).when(internet).testWebpage("https://thiswebsitedoesntwork.com/");
            when(internet.testWebpage("https://thiswebsitedoesntexist.com/")).thenThrow(new IOException("Could not resolve domain"));
            doThrow(new RuntimeException("Invalid url")).when(internet).testWebpage("httdsaasd");

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("Testing https://google.com");
            System.out.println(internet.testWebpage("https://google.com"));

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("Testing https://thiswebsitedoesntwork.com/");
            System.out.println(internet.testWebpage("https://thiswebsitedoesntwork.com/"));

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("Testing https://thiswebsitedoesntexist.com/");
            System.out.println(internet.testWebpage("https://thiswebsitedoesntexist.com/"));

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            System.out.println("Testing httdsaasd");
            System.out.println(internet.testWebpage("httdsaasd"));

        } catch (RuntimeException | IOException e) {
            System.out.println(e.getMessage());
        }

        try (MockedStatic<InternetStatic> utilities = Mockito.mockStatic(InternetStatic.class)) {
            utilities.when(() -> InternetStatic.testWebpage("https://google.com/")).thenReturn(true);
            System.out.println(InternetStatic.testWebpage("https://google.com/"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}