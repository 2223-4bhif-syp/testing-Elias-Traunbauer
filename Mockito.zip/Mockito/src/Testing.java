import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class Testing {

    @Mock
    Internet internet;

    @Test
    public void testClasses () {
        MockitoAnnotations.openMocks(this);

        try {

            when(internet.testWebpage("https://google.com")).thenReturn(true);
            when(internet.testWebpage("https://thiswebsitedoesntwork.com/")).thenReturn(false);
            when(internet.testWebpage("https://thiswebsitedoesntexist.com/")).thenThrow(new IOException("Could not resolve domain"));
            when(internet.testWebpage("httdsaasd")).thenThrow(new RuntimeException("Invalid url"));

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            assertEquals(internet.testWebpage("https://google.com"), true);

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        try {

            assertEquals(internet.testWebpage("https://thiswebsitedoesntwork.com/"), false);

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        assertThrows(IOException.class, () -> internet.testWebpage("https://thiswebsitedoesntexist.com/"));

        assertThrows(RuntimeException.class, () -> internet.testWebpage("httdsaasd"));
    }
}
