import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public final class InternetStatic {
    public static boolean testWebpage(String uurl) throws IOException {
        URL url = new URL(uurl);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("GET");
        return con.getResponseCode() == 200;
    }
}
